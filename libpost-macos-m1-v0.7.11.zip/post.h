#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#define CPU_PROVIDER_ID UINT32_MAX

typedef enum DeviceClass {
  DeviceClass_CPU = 1,
  DeviceClass_GPU = 2,
} DeviceClass;

typedef enum InitializeResult {
  InitializeResult_Ok = 0,
  InitializeResult_OkNonceNotFound = 1,
  InitializeResult_InvalidLabelsRange = 2,
  InitializeResult_Error = 3,
  InitializeResult_InvalidArgument = 4,
  InitializeResult_FailedToGetProviders = 5,
} InitializeResult;

/**
 * An enum representing the available verbosity levels of the logger.
 *
 * Typical usage includes: checking if a certain `Level` is enabled with
 * [`log_enabled!`](macro.log_enabled.html), specifying the `Level` of
 * [`log!`](macro.log.html), and comparing a `Level` directly to a
 * [`LevelFilter`](enum.LevelFilter.html).
 */
enum Level {
  /**
   * The "error" level.
   *
   * Designates very serious errors.
   */
  Level_Error = 1,
  /**
   * The "warn" level.
   *
   * Designates hazardous situations.
   */
  Level_Warn,
  /**
   * The "info" level.
   *
   * Designates useful information.
   */
  Level_Info,
  /**
   * The "debug" level.
   *
   * Designates lower priority information.
   */
  Level_Debug,
  /**
   * The "trace" level.
   *
   * Designates very low priority, often extremely verbose, information.
   */
  Level_Trace,
};
typedef uintptr_t Level;

typedef enum NewVerifierResult {
  NewVerifierResult_Ok,
  NewVerifierResult_InvalidArgument,
  NewVerifierResult_Failed,
} NewVerifierResult;

typedef struct Initializer Initializer;

typedef struct Verifier Verifier;

typedef struct Provider {
  char name[64];
  uint32_t id;
  enum DeviceClass class_;
} Provider;

typedef enum VerifyPosResult_Tag {
  VerifyPosResult_Ok,
  VerifyPosResult_Invalid,
  VerifyPosResult_InvalidArgument,
  VerifyPosResult_Failed,
} VerifyPosResult_Tag;

typedef struct VerifyPosResult_Invalid_Body {
  uintptr_t file;
  uint64_t offset;
} VerifyPosResult_Invalid_Body;

typedef struct VerifyPosResult {
  VerifyPosResult_Tag tag;
  union {
    VerifyPosResult_Invalid_Body invalid;
  };
} VerifyPosResult;

typedef struct ScryptParams {
  uintptr_t n;
  uintptr_t r;
  uintptr_t p;
} ScryptParams;

/**
 * FFI-safe borrowed Rust &str
 */
typedef struct StringView {
  const char *ptr;
  uintptr_t len;
} StringView;

typedef struct ExternCRecord {
  Level level;
  struct StringView message;
  struct StringView module_path;
  struct StringView file;
  int64_t line;
} ExternCRecord;

typedef struct ArrayU8 {
  uint8_t *ptr;
  uintptr_t len;
  uintptr_t cap;
} ArrayU8;

typedef struct Proof {
  uint32_t nonce;
  struct ArrayU8 indices;
  uint64_t pow;
} Proof;

typedef struct ProofConfig {
  /**
   * K1 specifies the difficulty for a label to be a candidate for a proof.
   */
  uint32_t k1;
  /**
   * K2 is the number of labels below the required difficulty required for a proof.
   */
  uint32_t k2;
  /**
   * Difficulty for the nonce proof of work. Lower values increase difficulty of finding
   * `pow` for [Proof][crate::prove::Proof].
   */
  uint8_t pow_difficulty[32];
} ProofConfig;

/**
 * RandomX Flags are used to configure the library.
 */
typedef uint32_t RandomXFlag;
/**
 * No flags set. Works on all platforms, but is the slowest.
 */
#define RandomXFlag_FLAG_DEFAULT (uint32_t)0
/**
 * Allocate memory in large pages.
 */
#define RandomXFlag_FLAG_LARGE_PAGES (uint32_t)1
/**
 * Use hardware accelerated AES.
 */
#define RandomXFlag_FLAG_HARD_AES (uint32_t)2
/**
 * Use the full dataset.
 */
#define RandomXFlag_FLAG_FULL_MEM (uint32_t)4
/**
 * Use JIT compilation support.
 */
#define RandomXFlag_FLAG_JIT (uint32_t)8
/**
 * When combined with FLAG_JIT, the JIT pages are never writable and executable at the
 * same time.
 */
#define RandomXFlag_FLAG_SECURE (uint32_t)16
/**
 * Optimize Argon2 for CPUs with the SSSE3 instruction set.
 */
#define RandomXFlag_FLAG_ARGON2_SSSE3 (uint32_t)32
/**
 * Optimize Argon2 for CPUs with the AVX2 instruction set.
 */
#define RandomXFlag_FLAG_ARGON2_AVX2 (uint32_t)64
/**
 * Optimize Argon2 for CPUs without the AVX2 or SSSE3 instruction sets.
 */
#define RandomXFlag_FLAG_ARGON2 (uint32_t)96

typedef enum VerifyResult_Tag {
  /**
   * Proof is valid
   */
  VerifyResult_Ok,
  /**
   * Invalid for other reasons
   */
  VerifyResult_Invalid,
  /**
   * Found invalid label
   * The index (in Proof.indices) of the index of invalid label is returned.
   * Say the proof has 3 indices [100, 200, 500] (these index labels in POS data),
   * if the label at index 200 is found invalid, the index 1 is returned.
   */
  VerifyResult_InvalidIndex,
  /**
   * Can't verify proof because invalid argument was passed
   */
  VerifyResult_InvalidArgument,
} VerifyResult_Tag;

typedef struct VerifyResult_InvalidIndex_Body {
  uintptr_t index_id;
} VerifyResult_InvalidIndex_Body;

typedef struct VerifyResult {
  VerifyResult_Tag tag;
  union {
    VerifyResult_InvalidIndex_Body invalid_index;
  };
} VerifyResult;

typedef struct ProofMetadata {
  uint8_t node_id[32];
  uint8_t commitment_atx_id[32];
  uint8_t challenge[32];
  uint32_t num_units;
} ProofMetadata;

/**
 * POST configuration (network parameter)
 */
typedef struct InitConfig {
  /**
   * The minimal number of units that must be initialized.
   */
  uint32_t min_num_units;
  /**
   * The maximal number of units that can be initialized.
   */
  uint32_t max_num_units;
  /**
   *  The number of labels per unit.
   */
  uint64_t labels_per_unit;
  /**
   * Scrypt paramters for initilizing labels
   */
  struct ScryptParams scrypt;
} InitConfig;

/**
 * Returns the number of providers available.
 */
uintptr_t get_providers_count(void);

/**
 * Returns all available providers.
 */
enum InitializeResult get_providers(struct Provider *out, uintptr_t out_len);

/**
 * Initializes labels for the given range.
 *
 * start and end are inclusive.
 */
enum InitializeResult initialize(struct Initializer *initializer,
                                 uint64_t start,
                                 uint64_t end,
                                 uint8_t *out_buffer,
                                 uint64_t *out_nonce);

struct Initializer *new_initializer(uint32_t provider_id,
                                    uintptr_t n,
                                    const uint8_t *commitment,
                                    const uint8_t *vrf_difficulty);

void free_initializer(struct Initializer *initializer);

struct VerifyPosResult verify_pos(const char *datadir,
                                  const uint32_t *from_file,
                                  const uint32_t *to_file,
                                  double fraction,
                                  struct ScryptParams scrypt);

/**
 * Set a logging callback function
 * The function is idempotent, calling it more then once will have no effect.
 * Returns 0 if the callback was set successfully, 1 otherwise.
 */
int32_t set_logging_callback(Level level, void (*callback)(const struct ExternCRecord*));

/**
 * Deallocate a proof obtained with generate_proof().
 * # Safety
 * `proof` must be a pointer to a Proof struct obtained with generate_proof().
 */
void free_proof(struct Proof *proof);

/**
 * Generates a proof of space for the given challenge using the provided parameters.
 * Returns a pointer to a Proof struct which should be freed with free_proof() after use.
 * If an error occurs, prints it on stderr and returns null.
 * # Safety
 * `challenge` must be a 32-byte array.
 */
struct Proof *generate_proof(const char *datadir,
                             const unsigned char *challenge,
                             struct ProofConfig cfg,
                             uintptr_t nonces,
                             uintptr_t threads,
                             RandomXFlag pow_flags);

/**
 * Get the recommended RandomX flags
 *
 * Does not include:
 * * FLAG_LARGE_PAGES
 * * FLAG_FULL_MEM
 * * FLAG_SECURE
 *
 * The above flags need to be set manually, if required.
 */
RandomXFlag recommended_pow_flags(void);

enum NewVerifierResult new_verifier(RandomXFlag flags, struct Verifier **out);

void free_verifier(struct Verifier *verifier);

/**
 * Verify the proof
 *
 * # Safety
 * - `verifier` must be initialized and properly aligned.
 * - `metadata` must be initialized and properly aligned.
 */
struct VerifyResult verify_proof(const struct Verifier *verifier,
                                 struct Proof proof,
                                 const struct ProofMetadata *metadata,
                                 struct ProofConfig cfg,
                                 struct InitConfig init_cfg);

/**
 * Verify a single index in the proof
 *
 * # Safety
 * - `verifier` must be initialized and properly aligned.
 * - `metadata` must be initialized and properly aligned.
 */
struct VerifyResult verify_proof_index(const struct Verifier *verifier,
                                       struct Proof proof,
                                       const struct ProofMetadata *metadata,
                                       struct ProofConfig cfg,
                                       struct InitConfig init_cfg,
                                       uintptr_t index);

/**
 * Verify a subset of indexes in the proof
 *
 * # Safety
 * - `verifier` must be initialized and properly aligned.
 * - `metadata` must be initialized and properly aligned.
 * - the caller must uphold the safety contract for `from_raw_parts`.
 */
struct VerifyResult verify_proof_subset(const struct Verifier *verifier,
                                        struct Proof proof,
                                        const struct ProofMetadata *metadata,
                                        struct ProofConfig cfg,
                                        struct InitConfig init_cfg,
                                        uintptr_t k3,
                                        const uint8_t *seed_ptr,
                                        uintptr_t seed_len);

const char *version(void);
